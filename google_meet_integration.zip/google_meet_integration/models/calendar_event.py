# -*- coding: utf-8 -*-
# Part of Odoo, Aktiv Software PVT. LTD.
# See LICENSE file for full copyright & licensing details.

from odoo import api, models , fields
from apiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from datetime import datetime, timedelta
import pickle

class CalendarEventNew(models.Model):
    _inherit = "calendar.event"

    genrate_google_meet_link = fields.Boolean(default=False)
    meeting_url = fields.Char()

    def join_meeting(self):
        print("\n\n\n you joined meeting...")
        return   { 
          'type': 'ir.actions.act_url',
          'url': self.meeting_url,
          'target' : 'new'
        }

    def create_calendar_event(self,pickle_file,name,description,start_datetime,stop_datetime,email_list):
        credentials = pickle.load(open(pickle_file, "rb"),encoding='latin1')
        print("credentials",credentials)
        service = build("calendar", "v3", credentials=credentials)
        # start_time = start_datetime
        # end_time = stop_datetime
        # timezone = 'Asia/Kolkata'
        emails = []

        for email in email_list:
            emails.append(
                     {'email': str(email)},
                )
        event = {
              "summary": name,
              "calendarId": "primary",
              "description" : description,
              "conferenceDataVersion": 1,
                'start': {
                    'dateTime': start_datetime.strftime("%Y-%m-%dT%H:%M:%S"),
                    'timeZone': 'Asia/Kolkata',
                },
                'end': {
                    'dateTime': stop_datetime.strftime("%Y-%m-%dT%H:%M:%S"),
                    'timeZone': 'Asia/Kolkata',
                },
              "conferenceData": {
                "createRequest": {
                  "conferenceSolutionKey": {
                    "type": "hangoutsMeet"
                  },
                  "requestId": "RandomString"
                }
              },
              'attendees': emails
              }

        event = service.events().insert(calendarId='primary',conferenceDataVersion=1, body=event).execute()
        print("create_calendar_event called...")
        return event.get("htmlLink"),event.get("hangoutLink")

    def write(self, values):
        #call new func called get data
        print("write method called...",values)
        pickle_file = "/home/odoo/Desktop/token_files/token.pkl"

        if values.get("attendee_ids") and self.genrate_google_meet_link:
            partner_ids = self.partner_ids
            email_list = []
            for partner_id in partner_ids:
                print("partner id",partner_id)
                rec = self.env['res.partner'].browse([partner_id.id])
                print(rec,rec.email)
                email_list.append(rec.email)
            calendar_url,meeting_url =  self.create_calendar_event(pickle_file,self.name,self.description,self.start_datetime,self.stop_datetime,email_list)

            values.update({
                'description' : f"\n\n:-::~:~::~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~::~:~::-\nDo not edit this section of the description.\n\nThis event has a video call.\nJoin: {meeting_url}\n\nView your event at {calendar_url}\n-::~:~::~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~:~::~:~::-",
                 'meeting_url' :    meeting_url
                })

        return super(CalendarEventNew, self).write(values) 

    # @api.model
    # def create(self, values):
    #     print("create method called...")
    