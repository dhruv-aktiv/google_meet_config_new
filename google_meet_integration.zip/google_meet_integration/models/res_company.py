# -*- coding: utf-8 -*-
# Part of Odoo, Aktiv Software PVT. LTD.
# See LICENSE file for full copyright & licensing details.

from odoo import api, models , fields
from apiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from datetime import datetime, timedelta
import pickle
import base64
import json


class ResCompany(models.Model):
    _inherit = 'res.company'

    google_client_secret_file = fields.Binary("Google Client Secret File", store=True, readonly=False)
    google_client_secret_pickle_file = fields.Binary("Google Client Secret Pickle File", store=True, readonly=True)

    @api.model
    def create(self, vals):
        print("create called...")
        # print(self.google_client_secret_file)
        # if self.google_client_secret_file:
        #     google_client_secret_file = base64.b64encode(self.google_client_secret_file)
        #     print(google_client_secret_file,"google_client_secret_file")
        # return super(ResCompany, self).create(values)

    
    # def write(self, vals):
    #     print("write called...")
    #     if self.google_client_secret_file:
    #         # google_client_secret_file = base64.b64encode(self.google_client_secret_file)
    #         # print(google_client_secret_file,"google_client_secret_file")
    #         # file_bytes = None
    #         # # read raw file bytes
    #         # with open(self.google_client_secret_file,'rb') as myfile:
    #         # base64.b64encode(attachment.read())

    #         # file_bytes = base64.b64encode(vals.get('google_client_secret_file'))

    #         # # encode, decode and put it in the JSON
    #         # filecontent = base64.encodebytes(file_bytes).decode('ascii')

    #         # # optionally serialize the JSON
    #         # serialized_json = json.dumps(filecontent)

    #         # print(serialized_json,"serialized_json")

    #         vals.update({
    #                 'google_client_secret_file' : base64.encodestring(json.dumps(vals.get('')).encode('utf-8'))
    #             })


    #     return super(ResCompany, self).write(vals)
    