# -*- coding: utf-8 -*-
# Part of Odoo, Aktiv Software
# See LICENSE file for full copyright & licensing details.

# Author: Aktiv Software
# mail: odoo@aktivsoftware.com
# Copyright (C) 2015-Present Aktiv Software
# Contributions:
# Aktiv Software:
# - Burhan Vakharia
# - Dhruv Suthar
# - Saurabh Yadav

{
    "name": "Odoo Google Meet Integration",
    "category": "Tools",
    "summary": """This module is allow user to schedule meeting from odoo to google calendar with google meet link.
    Odoo Google Meet Integration
    Google Meet
    Meet
    Google Meet Integration
    Meet Integration
    Odoo Google Meet Connector
    Google Meet Connector
    Meet Connector
    Schedule Google Meet Meeting 
    Meeting Schedule in Google Meet 
    """,
    "description": """
    Title: Google Meet Integration \n
    Author: Aktiv Software \n
    mail: odoo@aktivsoftware.com \n
    Copyright (C) 2015-Present Aktiv Software \n
    Contributions: Aktiv Software \n
                     - Burhan Vakharia
                     - Dhruv Suthar
                     - Saurabh Yadav
    This module is allow user to schedule meeting from odoo to google calendar with google meet link.
    Odoo Google Meet Integration
    Google Meet
    Meet
    Google Meet Integration
    Meet Integration
    Odoo Google Meet Connector
    Google Meet Connector
    Meet Connector
    Schedule Google Meet Meeting 
    Meeting Schedule in Google Meet         
    """,
    "author": "Aktiv Software",
    "website": "http://www.aktivesoftware.com",
    "version": "13.0.1.0.1",
    "depends": ["calendar"],
    "license": "OPL-1",
    "price": 25.00,
    "currency": "EUR",
    "data": [
        "views/res_company_view.xml",
        "views/calendar_event_view.xml",
        "views/calendar_event_template.xml"
    ],
    "application": False,
    "installable": True,
    "images": ["static/description/banner.jpg"],
}
